---
name: Imported procurement demo runtime
description: Environment-specific startup behavior for the imported pnpm workspace.
---

The imported workspace is a pnpm monorepo with artifact-managed services. The web artifact's Vite config intentionally fails when PORT or BASE_PATH is absent, so standalone builds must provide the same values as the managed artifact service.

**Why:** A missing node_modules directory initially masked this configuration requirement; dependency installation fixed the workflow, while a plain build still failed without the service environment.

**How to apply:** Prefer the managed artifact workflow for preview verification. For a one-off web build, provide the web service's configured port and base path rather than changing the Vite config.